"""
AutoShell - An AI-powered shell assistant.
"""

__version__ = "0.1.0"
__author__ = "Sriram Srikanth"