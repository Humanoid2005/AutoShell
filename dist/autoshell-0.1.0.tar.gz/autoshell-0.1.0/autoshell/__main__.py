#!/usr/bin/env python3
from autoshell.scripts.cli import main

if __name__ == "__main__":
    main()